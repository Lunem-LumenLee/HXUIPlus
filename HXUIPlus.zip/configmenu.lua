require ("common");
require('helpers');
local statusHandler = require('statushandler');
local imgui = require("imgui");

local config = {};

local alliedWhitelistSelected = { nil };
local alliedWhitelistInput = { '' };

local defaultAlliedWhitelist = T{
    ['Mhik Liusihlo, M.C.'] = true,
    ['Aeolia'] = true,
    ['Aesculian'] = true,
    ['Agent M97'] = true,
    ['Aletta'] = true,
    ['Alutanie'] = true,
    ['Andrus'] = true,
    ['Archimedes'] = true,
    ['Ash'] = true,
    ['Bagatrix'] = true,
    ['Bardus'] = true,
    ['Bella'] = true,
    ['Brittany'] = true,
    ['Captain Farrell'] = true,
    ['Carlo'] = true,
    ['Chilly Wolf'] = true,
    ['Cokhe Lokhe'] = true,
    ['Conchata-Potata'] = true,
    ['Couquillard'] = true,
    ['Cramp'] = true,
    ['Dadaroon'] = true,
    ['Disarmed Knight'] = true,
    ['Erbelie'] = true,
    ['Erudu-Faludu'] = true,
    ['Faded Footprint'] = true,
    ['Ferredec'] = true,
    ['Felyna'] = true,
    ['Fha Mhakyaa'] = true,
    ['Frerehn'] = true,
    ['Gan-Ban'] = true,
    ['Glenda'] = true,
    ['Gordo-Bordo'] = true,
    ['Hermin-Harmon'] = true,
    ['Hoi-Boi'] = true,
    ['Hume Footprint'] = true,
    ['Iron Digger'] = true,
    ['Iron Wolf'] = true,
    ['Jacquotte'] = true,
    ['Keenajaques'] = true,
    ['Khartes'] = true,
    ['Kirk'] = true,
    ['Lectilas'] = true,
    ['Letheb'] = true,
    ['Lewis'] = true,
    ['Manusiel'] = true,
    ['Master Lao'] = true,
    ['Mathias'] = true,
    ['Megasolus'] = true,
    ['Mithra Tracks'] = true,
    ['Moyeyo'] = true,
    ['Nangst'] = true,
    ['Nandiyah'] = true,
    ['Neavias'] = true,
    ['Nefari'] = true,
    ['Octavien'] = true,
    ['Passing Sunrise'] = true,
    ['Pedro'] = true,
    ['Pennana'] = true,
    ['Perah Celehsi'] = true,
    ['Perara'] = true,
    ['Portalix'] = true,
    ['Puluki-Culuki'] = true,
    ['Raving Fist'] = true,
    ['Reisle'] = true,
    ['Robineaux'] = true,
    ['Rumbling Valley'] = true,
    ['Rusty Hammer'] = true,
    ['Sebastian'] = true,
    ['Shady Dealer'] = true,
    ['Sharara'] = true,
    ['Shining Stone'] = true,
    ['Sinister Moon'] = true,
    ['Somnelius'] = true,
    ['Temimi'] = true,
    ['Tenebraux'] = true,
    ['Vermali'] = true,
    ['Verona'] = true,
    ['Yagudo Outlaw'] = true,
    ['The Patrician'] = true,
    ['Garrison Healer'] = true,
    ['Recruit'] = true,
};



config.DrawWindow = function(us)
    imgui.PushStyleColor(ImGuiCol_WindowBg, {0,0.06,.16,.9});
	imgui.PushStyleColor(ImGuiCol_TitleBg, {0,0.06,.16, .7});
	imgui.PushStyleColor(ImGuiCol_TitleBgActive, {0,0.06,.16, .9});
	imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, {0,0.06,.16, .5});
    imgui.PushStyleColor(ImGuiCol_Header, {0,0.06,.16,.7});
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, {0,0.06,.16, .9});
    imgui.PushStyleColor(ImGuiCol_HeaderActive, {0,0.06,.16, 1});
    imgui.PushStyleColor(ImGuiCol_FrameBg, {0,0.06,.16, 1});
    imgui.SetNextWindowSize({ 600, 600 }, ImGuiCond_FirstUseEver);
    if(showConfig[1] and imgui.Begin(("HXUIPlus Config"):fmt(addon.version), showConfig, bit.bor(ImGuiWindowFlags_NoSavedSettings))) then
        if(imgui.Button("Restore Defaults", { 130, 20 })) then
            ResetSettings();
            UpdateSettings();
        end
        imgui.SameLine();
        if(imgui.Button("Patch Notes", { 130, 20 })) then
            gConfig.patchNotesVer = -1;
            gShowPatchNotes = { true; }
            UpdateSettings();
        end
        imgui.BeginChild("Config Options", { 0, 0 }, true);
        if (imgui.CollapsingHeader("General")) then
            imgui.BeginChild("GeneralSettings", { 0, 210 }, true);
            if (imgui.Checkbox('Lock HUD Position', { gConfig.lockPositions })) then
                gConfig.lockPositions = not gConfig.lockPositions;
                UpdateSettings();
            end
            -- Status Icon Theme
            local status_theme_paths = statusHandler.get_status_theme_paths();
            if (imgui.BeginCombo('Status Icon Theme', gConfig.statusIconTheme)) then
                for i = 1,#status_theme_paths,1 do
                    local is_selected = i == gConfig.statusIconTheme;

                    if (imgui.Selectable(status_theme_paths[i], is_selected) and status_theme_paths[i] ~= gConfig.statusIconTheme) then
                        gConfig.statusIconTheme = status_theme_paths[i];
                        statusHandler.clear_cache();
                        UpdateSettings();
                    end

                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end
            imgui.ShowHelp('The folder to pull status icons from. [HXUIPlus\\assets\\status]');

            -- Job Icon Theme
            local job_theme_paths = statusHandler.get_job_theme_paths();
            if (imgui.BeginCombo('Job Icon Theme', gConfig.jobIconTheme)) then
                for i = 1,#job_theme_paths,1 do
                    local is_selected = i == gConfig.jobIconTheme;

                    if (imgui.Selectable(job_theme_paths[i], is_selected) and job_theme_paths[i] ~= gConfig.jobIconTheme) then
                        gConfig.jobIconTheme = job_theme_paths[i];
                        statusHandler.clear_cache();
                        UpdateSettings();
                    end

                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end
            imgui.ShowHelp('The folder to pull job icons from. [HXUIPlus\\assets\\jobs]');

            if (imgui.Checkbox('Show Health Bar Flash Effects', { gConfig.healthBarFlashEnabled })) then
                gConfig.healthBarFlashEnabled = not gConfig.healthBarFlashEnabled;
                UpdateSettings();
            end

            local noBookendRounding = { gConfig.noBookendRounding };
            if (imgui.SliderInt('Basic Bar Roundness', noBookendRounding, 0, 10)) then
                gConfig.noBookendRounding = noBookendRounding[1];
                UpdateSettings();
            end
            imgui.ShowHelp('For bars with no bookends, how round they should be.');

            local tooltipScale = { gConfig.tooltipScale };
            if (imgui.SliderFloat('Tooltip Scale', tooltipScale, 0.1, 3.0, '%.2f')) then
                gConfig.tooltipScale = tooltipScale[1];
                UpdateSettings();
            end
            imgui.ShowHelp('Scales the size of the tooltip. Note that text may appear blured if scaled too large.');

            if (imgui.Checkbox('Hide During Events', { gConfig.hideDuringEvents })) then
                gConfig.hideDuringEvents = not gConfig.hideDuringEvents;
                UpdateSettings();
            end

            imgui.EndChild();
        end
        if (imgui.CollapsingHeader("Player Bar")) then
            imgui.BeginChild("PlayerBarSettings", { 0, 210 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showPlayerBar })) then
                gConfig.showPlayerBar = not gConfig.showPlayerBar;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showPlayerBarBookends })) then
                gConfig.showPlayerBarBookends = not gConfig.showPlayerBarBookends;
                UpdateSettings();
            end
            if (imgui.Checkbox('Hide During Events', { gConfig.playerBarHideDuringEvents })) then
                gConfig.playerBarHideDuringEvents = not gConfig.playerBarHideDuringEvents;
                UpdateSettings();
            end
            if (imgui.Checkbox('Always Show MP Bar', { gConfig.alwaysShowMpBar })) then
                gConfig.alwaysShowMpBar = not gConfig.alwaysShowMpBar;
                UpdateSettings();
            end
            imgui.ShowHelp('Always display the MP Bar even if your current jobs cannot cast spells.'); 
            local scaleX = { gConfig.playerBarScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.1f')) then
                gConfig.playerBarScaleX = scaleX[1];
                UpdateSettings();
            end
            local scaleY = { gConfig.playerBarScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.1f')) then
                gConfig.playerBarScaleY = scaleY[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.playerBarFontOffset };
            if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                gConfig.playerBarFontOffset = fontOffset[1];
                UpdateSettings();
            end
            imgui.EndChild();
        end
        if (imgui.CollapsingHeader("Target Bar")) then
            imgui.BeginChild("TargetBarSettings", { 0, 300 }, true);

            if (imgui.Checkbox('Enabled', { gConfig.showTargetBar })) then
                gConfig.showTargetBar = not gConfig.showTargetBar;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showTargetBarBookends })) then
                gConfig.showTargetBarBookends = not gConfig.showTargetBarBookends;
                UpdateSettings();
            end
            if (imgui.Checkbox('Hide During Events', { gConfig.targetBarHideDuringEvents })) then
                gConfig.targetBarHideDuringEvents = not gConfig.targetBarHideDuringEvents;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Enemy Id', { gConfig.showEnemyId })) then
                gConfig.showEnemyId = not gConfig.showEnemyId;
                UpdateSettings();
            end
            imgui.ShowHelp('Display the internal ID of the monster next to its name.'); 
            if (imgui.Checkbox('Always Show Health Percent', { gConfig.alwaysShowHealthPercent })) then
                gConfig.alwaysShowHealthPercent = not gConfig.alwaysShowHealthPercent;
                UpdateSettings();
            end
            imgui.ShowHelp('Always display the percent of HP remanining regardless if the target is an enemy or not.');

            if (imgui.Checkbox('Darken HP Bar When Out Of Range', { gConfig.targetBarDarkenHpOutOfRange })) then
                gConfig.targetBarDarkenHpOutOfRange = not gConfig.targetBarDarkenHpOutOfRange;
                UpdateSettings();
            end

            local scaleX = { gConfig.targetBarScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.1f')) then
                gConfig.targetBarScaleX = scaleX[1];
                UpdateSettings();
            end
            local scaleY = { gConfig.targetBarScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.1f')) then
                gConfig.targetBarScaleY = scaleY[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.targetBarFontOffset };
            if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                gConfig.targetBarFontOffset = fontOffset[1];
                UpdateSettings();
            end
            local iconScale = { gConfig.targetBarIconScale };
            if (imgui.SliderFloat('Icon Scale', iconScale, 0.1, 3.0, '%.1f')) then
                gConfig.targetBarIconScale = iconScale[1];
                UpdateSettings();
            end
            imgui.EndChild();
			end
			if (imgui.CollapsingHeader("Enemy List")) then
            imgui.BeginChild("EnemyListSettings", { 0, 240 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showEnemyList })) then
                gConfig.showEnemyList = not gConfig.showEnemyList;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showEnemyListBookends })) then
                gConfig.showEnemyListBookends = not gConfig.showEnemyListBookends;
                UpdateSettings();
            end
            local scaleX = { gConfig.enemyListScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.1f')) then
                gConfig.enemyListScaleX = scaleX[1];
                UpdateSettings();
            end
            local scaleY = { gConfig.enemyListScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.1f')) then
                gConfig.enemyListScaleY = scaleY[1];
                UpdateSettings();
            end
            local fontScale = { gConfig.enemyListFontScale };
            if (imgui.SliderFloat('Font Scale', fontScale, 0.1, 3.0, '%.1f')) then
                gConfig.enemyListFontScale = fontScale[1];
                UpdateSettings();
            end
            local iconScale = { gConfig.enemyListIconScale };
            if (imgui.SliderFloat('Icon Scale', iconScale, 0.1, 3.0, '%.1f')) then
                gConfig.enemyListIconScale = iconScale[1];
                UpdateSettings();
            end

            local posItems = {};
            posItems[0] = 'Left';
            posItems[1] = 'Right';
            gConfig.enemyListStatusIconPosition = math.clamp(gConfig.enemyListStatusIconPosition or 1, 0, 1);
            if (imgui.BeginCombo('Status Icon Position', posItems[gConfig.enemyListStatusIconPosition])) then
                for i = 0, #posItems do
                    local is_selected = i == gConfig.enemyListStatusIconPosition;
                    if (imgui.Selectable(posItems[i], is_selected) and gConfig.enemyListStatusIconPosition ~= i) then
                        gConfig.enemyListStatusIconPosition = i;
                        UpdateSettings();
                    end
                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end

            gConfig.enemyListRangeDistance = tonumber(gConfig.enemyListRangeDistance) or 21.8;
            local enemyRangeDist = { gConfig.enemyListRangeDistance };
            if (imgui.InputFloat('Range Distance', enemyRangeDist, 0.1, 1.0, '%.1f')) then
                gConfig.enemyListRangeDistance = enemyRangeDist[1];
                UpdateSettings();
            end

            imgui.EndChild();


        end
        if (imgui.CollapsingHeader("Allied Forces")) then
            imgui.BeginChild("AlliedForcesSettings", { 0, 420 }, true);

            if (imgui.Checkbox('Enabled', { gConfig.showAlliedForces })) then
                gConfig.showAlliedForces = not gConfig.showAlliedForces;
                UpdateSettings();
            end

            if (imgui.Checkbox('Preview Full Allied List (when config open)', { gConfig.alliedListPreview })) then
                gConfig.alliedListPreview = not gConfig.alliedListPreview;
                UpdateSettings();
            end

            if (imgui.Checkbox('Show Bookends', { gConfig.showAlliedListBookends })) then
                gConfig.showAlliedListBookends = not gConfig.showAlliedListBookends;
                UpdateSettings();
            end

            if (imgui.Checkbox('Show Title', { gConfig.showAlliedListTitle })) then
                gConfig.showAlliedListTitle = not gConfig.showAlliedListTitle;
                UpdateSettings();
            end

            if (imgui.Checkbox('Hide During Events', { gConfig.alliedListHideDuringEvents })) then
                gConfig.alliedListHideDuringEvents = not gConfig.alliedListHideDuringEvents;
                UpdateSettings();
            end

            if (imgui.Checkbox('Align Bottom', { gConfig.alliedListAlignBottom })) then
                gConfig.alliedListAlignBottom = not gConfig.alliedListAlignBottom;
                UpdateSettings();
            end

            local scaleX = { gConfig.alliedListScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.1f')) then
                gConfig.alliedListScaleX = scaleX[1];
                UpdateSettings();
            end

            local scaleY = { gConfig.alliedListScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.1f')) then
                gConfig.alliedListScaleY = scaleY[1];
                UpdateSettings();
            end

            local fontScale = { gConfig.alliedListFontScale };
            if (imgui.SliderFloat('Font Scale', fontScale, 0.1, 3.0, '%.1f')) then
                gConfig.alliedListFontScale = fontScale[1];
                UpdateSettings();
            end

            local entrySpacing = { gConfig.alliedListEntrySpacing };
            if (imgui.SliderInt('Entry Spacing', entrySpacing, -20, 20)) then
                gConfig.alliedListEntrySpacing = entrySpacing[1];
                UpdateSettings();
            end

            gConfig.alliedListRangeDistance = tonumber(gConfig.alliedListRangeDistance) or 21.8;
            local rangeDist = { gConfig.alliedListRangeDistance };
            if (imgui.InputFloat('Range Distance', rangeDist, 0.1, 1.0, '%.1f')) then
                gConfig.alliedListRangeDistance = rangeDist[1];
                UpdateSettings();
            end

            gConfig.alliedWhitelist = gConfig.alliedWhitelist or T{};
            if (next(gConfig.alliedWhitelist) == nil and gConfig.alliedWhitelistSeeded ~= true) then
                for k,v in pairs(defaultAlliedWhitelist) do
                    gConfig.alliedWhitelist[k] = v;
                end
                gConfig.alliedWhitelistSeeded = true;
                UpdateSettings();
            end


            imgui.Separator();
            imgui.Text('Allied Whitelist');

            imgui.BeginChild('AlliedWhitelistBox', { 0, 160 }, true);
            do
                local names = {};
                for k,_ in pairs(gConfig.alliedWhitelist) do
                    if (type(k) == 'string' and k ~= '') then
                        table.insert(names, k);
                    end
                end
                table.sort(names);

                for i = 1, #names do
                    local n = names[i];
                    local is_selected = (alliedWhitelistSelected[1] == n);
                    if (imgui.Selectable(n, is_selected)) then
                        alliedWhitelistSelected[1] = n;
                        alliedWhitelistInput[1] = n;
                    end
                end
            end
            imgui.EndChild();

            imgui.InputText('Name', alliedWhitelistInput, 256);

            if (imgui.Button('Add / Update', { 120, 20 })) then
                local newName = tostring(alliedWhitelistInput[1] or '');
                if (newName ~= '') then
                    if (alliedWhitelistSelected[1] ~= nil and alliedWhitelistSelected[1] ~= newName) then
                        gConfig.alliedWhitelist[alliedWhitelistSelected[1]] = nil;
                    end
                    gConfig.alliedWhitelist[newName] = true;
                    alliedWhitelistSelected[1] = newName;
                    UpdateSettings();
                end
            end

            imgui.SameLine();
            if (imgui.Button('Delete', { 80, 20 })) then
                if (alliedWhitelistSelected[1] ~= nil) then
                    gConfig.alliedWhitelist[alliedWhitelistSelected[1]] = nil;
                    alliedWhitelistSelected[1] = nil;
                    alliedWhitelistInput[1] = '';
                    UpdateSettings();
                end
            end

            imgui.EndChild();

        end


        if (imgui.CollapsingHeader("Party List")) then

            imgui.BeginChild("PartyListSettings", { 0, 560 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showPartyList })) then
                gConfig.showPartyList = not gConfig.showPartyList;
                UpdateSettings();
            end
            if (imgui.Checkbox('Preview Full Party (when config open)', { gConfig.partyListPreview })) then
                gConfig.partyListPreview = not gConfig.partyListPreview;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showPartyListBookends })) then
                gConfig.showPartyListBookends = not gConfig.showPartyListBookends;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show When Solo', { gConfig.showPartyListWhenSolo })) then
                gConfig.showPartyListWhenSolo = not gConfig.showPartyListWhenSolo;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Title', { gConfig.showPartyListTitle })) then
                gConfig.showPartyListTitle = not gConfig.showPartyListTitle;
                UpdateSettings();
            end
            if (imgui.Checkbox('Hide During Events', { gConfig.partyListHideDuringEvents })) then
                gConfig.partyListHideDuringEvents = not gConfig.partyListHideDuringEvents;
                UpdateSettings();
            end
            if (imgui.Checkbox('Align Bottom', { gConfig.partyListAlignBottom })) then
                gConfig.partyListAlignBottom = not gConfig.partyListAlignBottom;
                UpdateSettings();
            end
            if (imgui.Checkbox('Expand Height', { gConfig.partyListExpandHeight })) then
                gConfig.partyListExpandHeight = not gConfig.partyListExpandHeight;
                UpdateSettings();
            end
            if (imgui.Checkbox('Alliance Windows', { gConfig.partyListAlliance })) then
                gConfig.partyListAlliance = not gConfig.partyListAlliance;
                UpdateSettings();
            end

            -- Background
            local bgScale = { gConfig.partyListBgScale };
            if (imgui.SliderFloat('Background Scale', bgScale, 0.1, 3.0, '%.2f')) then
                gConfig.partyListBgScale = bgScale[1];
                UpdateSettings();
            end

            local bgColor = { gConfig.partyListBgColor[1] / 255, gConfig.partyListBgColor[2] / 255, gConfig.partyListBgColor[3] / 255, gConfig.partyListBgColor[4] / 255 };
            if (imgui.ColorEdit4('Background Color', bgColor, ImGuiColorEditFlags_AlphaBar)) then
                gConfig.partyListBgColor[1] = bgColor[1] * 255;
                gConfig.partyListBgColor[2] = bgColor[2] * 255;
                gConfig.partyListBgColor[3] = bgColor[3] * 255;
                gConfig.partyListBgColor[4] = bgColor[4] * 255;
                UpdateSettings();
            end

            local borderColor = { gConfig.partyListBorderColor[1] / 255, gConfig.partyListBorderColor[2] / 255, gConfig.partyListBorderColor[3] / 255, gConfig.partyListBorderColor[4] / 255 };
            if (imgui.ColorEdit4('Selected Color', borderColor, ImGuiColorEditFlags_AlphaBar)) then
                gConfig.partyListBorderColor[1] = borderColor[1] * 255;
                gConfig.partyListBorderColor[2] = borderColor[2] * 255;
                gConfig.partyListBorderColor[3] = borderColor[3] * 255;
                gConfig.partyListBorderColor[4] = borderColor[4] * 255;
                UpdateSettings();
            end

            gConfig.partyListOorHpColor = gConfig.partyListOorHpColor or { 21, 21, 21 };
            gConfig.partyListOorMpColor = gConfig.partyListOorMpColor or { 43, 43, 43 };
            gConfig.partyListOorTpColor = gConfig.partyListOorTpColor or { 43, 43, 43 };

            local oorHp = { gConfig.partyListOorHpColor[1] / 255, gConfig.partyListOorHpColor[2] / 255, gConfig.partyListOorHpColor[3] / 255, 1.0 };
            if (imgui.ColorEdit4('OOR HP Bar', oorHp, ImGuiColorEditFlags_NoAlpha)) then
                gConfig.partyListOorHpColor[1] = oorHp[1] * 255;
                gConfig.partyListOorHpColor[2] = oorHp[2] * 255;
                gConfig.partyListOorHpColor[3] = oorHp[3] * 255;
                UpdateSettings();
            end

            local oorMp = { gConfig.partyListOorMpColor[1] / 255, gConfig.partyListOorMpColor[2] / 255, gConfig.partyListOorMpColor[3] / 255, 1.0 };
            if (imgui.ColorEdit4('OOR MP Bar', oorMp, ImGuiColorEditFlags_NoAlpha)) then
                gConfig.partyListOorMpColor[1] = oorMp[1] * 255;
                gConfig.partyListOorMpColor[2] = oorMp[2] * 255;
                gConfig.partyListOorMpColor[3] = oorMp[3] * 255;
                UpdateSettings();
            end

            local oorTp = { gConfig.partyListOorTpColor[1] / 255, gConfig.partyListOorTpColor[2] / 255, gConfig.partyListOorTpColor[3] / 255, 1.0 };
            if (imgui.ColorEdit4('OOR TP Bar', oorTp, ImGuiColorEditFlags_NoAlpha)) then
                gConfig.partyListOorTpColor[1] = oorTp[1] * 255;
                gConfig.partyListOorTpColor[2] = oorTp[2] * 255;
                gConfig.partyListOorTpColor[3] = oorTp[3] * 255;
                UpdateSettings();
            end

            local bg_theme_paths = statusHandler.get_background_paths();
            if (imgui.BeginCombo('Background', gConfig.partyListBackgroundName)) then
                for i = 1,#bg_theme_paths,1 do
                    local is_selected = i == gConfig.partyListBackgroundName;

                    if (imgui.Selectable(bg_theme_paths[i], is_selected) and bg_theme_paths[i] ~= gConfig.partyListBackgroundName) then
                        gConfig.partyListBackgroundName = bg_theme_paths[i];
                        statusHandler.clear_cache();
                        UpdateSettings();
                    end

                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end
            imgui.ShowHelp('The image to use for the party list background. [Resolution: 512x512 @ HXUIPlus\\assets\\backgrounds]'); 
            
            -- Arrow
            local cursor_paths = statusHandler.get_cursor_paths();
            if (imgui.BeginCombo('Cursor', gConfig.partyListCursor)) then
                for i = 1,#cursor_paths,1 do
                    local is_selected = i == gConfig.partyListCursor;

                    if (imgui.Selectable(cursor_paths[i], is_selected) and cursor_paths[i] ~= gConfig.partyListCursor) then
                        gConfig.partyListCursor = cursor_paths[i];
                        statusHandler.clear_cache();
                        UpdateSettings();
                    end

                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end
            imgui.ShowHelp('The image to use for the party list cursor. [@ HXUIPlus\\assets\\cursors]'); 
            

            local comboBoxItems = {};
            comboBoxItems[0] = 'HorizonXI';
            comboBoxItems[1] = 'HorizonXI-R';
            comboBoxItems[2] = 'FFXIV';
            comboBoxItems[3] = 'FFXI';
            comboBoxItems[4] = 'Disabled';
            gConfig.partyListStatusTheme = math.clamp(gConfig.partyListStatusTheme, 0, 4);
            if(imgui.BeginCombo('Status Theme', comboBoxItems[gConfig.partyListStatusTheme])) then
                for i = 0,#comboBoxItems do
                    local is_selected = i == gConfig.partyListStatusTheme;

                    if (imgui.Selectable(comboBoxItems[i], is_selected) and gConfig.partyListStatusTheme ~= i) then
                        gConfig.partyListStatusTheme = i;
                        UpdateSettings();
                    end
                    if(is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end

            local buffScale = { gConfig.partyListBuffScale };
            if (imgui.SliderFloat('Status Icon Scale', buffScale, 0.1, 3.0, '%.1f')) then
                gConfig.partyListBuffScale = buffScale[1];
                UpdateSettings();
            end

            local posItems = {};
            posItems[0] = 'Left';
            posItems[1] = 'Right';
            gConfig.partyListStatusIconPosition = math.clamp(gConfig.partyListStatusIconPosition or 0, 0, 1);
            if (imgui.BeginCombo('Status Icon Position', posItems[gConfig.partyListStatusIconPosition])) then
                for i = 0, #posItems do
                    local is_selected = i == gConfig.partyListStatusIconPosition;
                    if (imgui.Selectable(posItems[i], is_selected) and gConfig.partyListStatusIconPosition ~= i) then
                        gConfig.partyListStatusIconPosition = i;
                        UpdateSettings();
                    end
                    if (is_selected) then
                        imgui.SetItemDefaultFocus();
                    end
                end
                imgui.EndCombo();
            end

            gConfig.partyListRangeDistance = tonumber(gConfig.partyListRangeDistance) or 21.8;
            local partyRangeDist = { gConfig.partyListRangeDistance };
            if (imgui.InputFloat('Range Distance', partyRangeDist, 0.1, 1.0, '%.1f')) then
                gConfig.partyListRangeDistance = partyRangeDist[1];
                UpdateSettings();
            end

            imgui.EndChild();


            if true then
                imgui.BeginChild('PartyListSettings.Party1', { 0, 230 }, true);
                imgui.Text('Party');

                if (imgui.Checkbox('Show TP', { gConfig.partyListTP })) then
                    gConfig.partyListTP = not gConfig.partyListTP;
                    UpdateSettings();
                end

                local minRows = { gConfig.partyListMinRows };
                if (imgui.SliderInt('Min Rows', minRows, 1, 6)) then
                    gConfig.partyListMinRows = minRows[1];
                    UpdateSettings();
                end

                local scaleX = { gConfig.partyListScaleX };
                if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.2f')) then
                    gConfig.partyListScaleX = scaleX[1];
                    UpdateSettings();
                end
                local scaleY = { gConfig.partyListScaleY };
                if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.2f')) then
                    gConfig.partyListScaleY = scaleY[1];
                    UpdateSettings();
                end

                local fontOffset = { gConfig.partyListFontOffset };
                if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                    gConfig.partyListFontOffset = fontOffset[1];
                    UpdateSettings();
                end

                local jobIconScale = { gConfig.partyListJobIconScale };
                if (imgui.SliderFloat('Job Icon Scale', jobIconScale, 0.1, 3.0, '%.1f')) then
                    gConfig.partyListJobIconScale = jobIconScale[1];
                    UpdateSettings();
                end

                local entrySpacing = { gConfig.partyListEntrySpacing };
                if (imgui.SliderInt('Entry Spacing', entrySpacing, -20, 20)) then
                    gConfig.partyListEntrySpacing = entrySpacing[1];
                    UpdateSettings();
                end

                imgui.EndChild();
            end

            if (gConfig.partyListAlliance) then
                imgui.BeginChild('PartyListSettings.Party2', { 0, 205 }, true);
                imgui.Text('Party B (Alliance)');

                if (imgui.Checkbox('Show TP', { gConfig.partyList2TP })) then
                    gConfig.partyList2TP = not gConfig.partyList2TP;
                    UpdateSettings();
                end

                local scaleX = { gConfig.partyList2ScaleX };
                if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.2f')) then
                    gConfig.partyList2ScaleX = scaleX[1];
                    UpdateSettings();
                end
                local scaleY = { gConfig.partyList2ScaleY };
                if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.2f')) then
                    gConfig.partyList2ScaleY = scaleY[1];
                    UpdateSettings();
                end

                local fontOffset = { gConfig.partyList2FontOffset };
                if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                    gConfig.partyList2FontOffset = fontOffset[1];
                    UpdateSettings();
                end

                local jobIconScale = { gConfig.partyList2JobIconScale };
                if (imgui.SliderFloat('Job Icon Scale', jobIconScale, 0.1, 3.0, '%.1f')) then
                    gConfig.partyList2JobIconScale = jobIconScale[1];
                    UpdateSettings();
                end

                local entrySpacing = { gConfig.partyList2EntrySpacing };
                if (imgui.SliderInt('Entry Spacing', entrySpacing, -20, 20)) then
                    gConfig.partyList2EntrySpacing = entrySpacing[1];
                    UpdateSettings();
                end

                imgui.EndChild();
            end

            if (gConfig.partyListAlliance) then
                imgui.BeginChild('PartyListSettings.Party3', { 0, 205 }, true);
                imgui.Text('Party C (Alliance)');

                if (imgui.Checkbox('Show TP', { gConfig.partyList3TP })) then
                    gConfig.partyList3TP = not gConfig.partyList3TP;
                    UpdateSettings();
                end

                local scaleX = { gConfig.partyList3ScaleX };
                if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.2f')) then
                    gConfig.partyList3ScaleX = scaleX[1];
                    UpdateSettings();
                end
                local scaleY = { gConfig.partyList3ScaleY };
                if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.2f')) then
                    gConfig.partyList3ScaleY = scaleY[1];
                    UpdateSettings();
                end

                local fontOffset = { gConfig.partyList3FontOffset };
                if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                    gConfig.partyList3FontOffset = fontOffset[1];
                    UpdateSettings();
                end

                local jobIconScale = { gConfig.partyList3JobIconScale };
                if (imgui.SliderFloat('Job Icon Scale', jobIconScale, 0.1, 3.0, '%.1f')) then
                    gConfig.partyList3JobIconScale = jobIconScale[1];
                    UpdateSettings();
                end

                local entrySpacing = { gConfig.partyList3EntrySpacing };
                if (imgui.SliderInt('Entry Spacing', entrySpacing, -20, 20)) then
                    gConfig.partyList3EntrySpacing = entrySpacing[1];
                    UpdateSettings();
                end

                imgui.EndChild();
            end
        end
        if (imgui.CollapsingHeader("Exp Bar")) then
            imgui.BeginChild("ExpBarSettings", { 0, 300 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showExpBar })) then
                gConfig.showExpBar = not gConfig.showExpBar;
                UpdateSettings();
            end
            if (imgui.Checkbox('Limit Points Mode', { gConfig.expBarLimitPointsMode })) then
                gConfig.expBarLimitPointsMode = not gConfig.expBarLimitPointsMode;
                UpdateSettings();
            end
            imgui.ShowHelp('Shows Limit Points if character is set to earn Limit Points in the game.');
            if (imgui.Checkbox('Inline Mode', { gConfig.expBarInlineMode })) then
                gConfig.expBarInlineMode = not gConfig.expBarInlineMode;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showExpBarBookends })) then
                gConfig.showExpBarBookends = not gConfig.showExpBarBookends;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Text', { gConfig.expBarShowText })) then
                gConfig.expBarShowText = not gConfig.expBarShowText;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Percent', { gConfig.expBarShowPercent })) then
                gConfig.expBarShowPercent = not gConfig.expBarShowPercent;
                UpdateSettings();
            end
            local scaleX = { gConfig.expBarScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.2f')) then
                gConfig.expBarScaleX = scaleX[1];
                UpdateSettings();
            end
            local scaleY = { gConfig.expBarScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.2f')) then
                gConfig.expBarScaleY = scaleY[1];
                UpdateSettings();
            end
            local textScaleX = { gConfig.expBarTextScaleX };
            if (imgui.SliderFloat('Text Scale X', textScaleX, 0.1, 3.0, '%.2f')) then
                gConfig.expBarTextScaleX = textScaleX[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.expBarFontOffset };
            if (imgui.SliderInt('Font Height', fontOffset, -5, 10)) then
                gConfig.expBarFontOffset = fontOffset[1];
                UpdateSettings();
            end
            imgui.EndChild();
        end
        if (imgui.CollapsingHeader("Gil Tracker")) then
            imgui.BeginChild("GilTrackerSettings", { 0, 160 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showGilTracker })) then
                gConfig.showGilTracker = not gConfig.showGilTracker;
                UpdateSettings();
            end
            local scale = { gConfig.gilTrackerScale };
            if (imgui.SliderFloat('Scale', scale, 0.1, 3.0, '%.1f')) then
                gConfig.gilTrackerScale = scale[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.gilTrackerFontOffset };
            if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                gConfig.gilTrackerFontOffset = fontOffset[1];
                UpdateSettings();
            end
            if (imgui.Checkbox('Right Align', { gConfig.gilTrackerRightAlign })) then
                gConfig.gilTrackerRightAlign = not gConfig.gilTrackerRightAlign;
                UpdateSettings();
            end
            local posOffset = { gConfig.gilTrackerPosOffset[1], gConfig.gilTrackerPosOffset[2] };
            if (imgui.InputInt2('Position Offset', posOffset)) then
                gConfig.gilTrackerPosOffset[1] = posOffset[1];
                gConfig.gilTrackerPosOffset[2] = posOffset[2];
                UpdateSettings();
            end
            imgui.EndChild();
        end
        if (imgui.CollapsingHeader("Inventory Tracker")) then
            imgui.BeginChild("InventoryTrackerSettings", { 0, 210 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showInventoryTracker })) then
                gConfig.showInventoryTracker = not gConfig.showInventoryTracker;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Count', { gConfig.inventoryShowCount })) then
                gConfig.inventoryShowCount = not gConfig.inventoryShowCount;
                UpdateSettings();
            end
            local columnCount = { gConfig.inventoryTrackerColumnCount };
            if (imgui.SliderInt('Columns', columnCount, 1, 80)) then
                gConfig.inventoryTrackerColumnCount = columnCount[1];
                UpdateSettings();
            end
            local rowCount = { gConfig.inventoryTrackerRowCount };
            if (imgui.SliderInt('Rows', rowCount, 1, 80)) then
                gConfig.inventoryTrackerRowCount = rowCount[1];
                UpdateSettings();
            end
            local opacity = { gConfig.inventoryTrackerOpacity };
            if (imgui.SliderFloat('Opacity', opacity, 0, 1.0, '%.2f')) then
                gConfig.inventoryTrackerOpacity = opacity[1];
                UpdateSettings();
            end
            local scale = { gConfig.inventoryTrackerScale };
            if (imgui.SliderFloat('Scale', scale, 0.1, 3.0, '%.1f')) then
                gConfig.inventoryTrackerScale = scale[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.inventoryTrackerFontOffset };
            if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                gConfig.inventoryTrackerFontOffset = fontOffset[1];
                UpdateSettings();
            end
            imgui.EndChild();
        end
        if (imgui.CollapsingHeader("Cast Bar")) then
            imgui.BeginChild("CastBarSettings", { 0, 160 }, true);
            if (imgui.Checkbox('Enabled', { gConfig.showCastBar })) then
                gConfig.showCastBar = not gConfig.showCastBar;
                UpdateSettings();
            end
            if (imgui.Checkbox('Show Bookends', { gConfig.showCastBarBookends })) then
                gConfig.showCastBarBookends = not gConfig.showCastBarBookends;
                UpdateSettings();
            end
            local scaleX = { gConfig.castBarScaleX };
            if (imgui.SliderFloat('Scale X', scaleX, 0.1, 3.0, '%.1f')) then
                gConfig.castBarScaleX = scaleX[1];
                UpdateSettings();
            end
            local scaleY = { gConfig.castBarScaleY };
            if (imgui.SliderFloat('Scale Y', scaleY, 0.1, 3.0, '%.1f')) then
                gConfig.castBarScaleY = scaleY[1];
                UpdateSettings();
            end
            local fontOffset = { gConfig.castBarFontOffset };
            if (imgui.SliderInt('Font Scale', fontOffset, -5, 10)) then
                gConfig.castBarFontOffset = fontOffset[1];
                UpdateSettings();
            end
            imgui.EndChild();
        end
        imgui.EndChild();
    end
    imgui.PopStyleColor(8);
	imgui.End();
end

return config;